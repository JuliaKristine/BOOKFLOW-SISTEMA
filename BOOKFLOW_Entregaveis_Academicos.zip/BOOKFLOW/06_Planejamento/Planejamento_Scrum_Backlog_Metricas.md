# Planejamento de implementação — BOOKFLOW

## Product Backlog inicial
| ID | User Story | Prioridade | Story Points |
|---|---|---:|---:|
| US01 | Como usuário, quero autenticar para acessar recursos autorizados | Alta | 8 |
| US02 | Como administrador, quero gerenciar usuários e perfis | Alta | 8 |
| US03 | Como bibliotecário, quero cadastrar livros | Alta | 5 |
| US04 | Como bibliotecário, quero controlar exemplares | Alta | 5 |
| US05 | Como leitor, quero pesquisar o catálogo | Alta | 5 |
| US06 | Como bibliotecário, quero registrar empréstimos validados | Alta | 8 |
| US07 | Como bibliotecário, quero registrar devoluções | Alta | 5 |
| US08 | Como leitor, quero reservar livros e acompanhar a fila | Média | 8 |
| US09 | Como gestor, quero consultar relatórios | Média | 8 |
| US10 | Como leitor, quero receber notificações | Média | 5 |

## Sprints
1. Requisitos e arquitetura: backlog, personas, fluxos, arquitetura e protótipo.
2. Banco, autenticação e usuários: schema, login, perfis, CRUD de usuários.
3. Acervo: livros, autores, categorias, editoras e exemplares.
4. Circulação: empréstimos, regras, devoluções e histórico.
5. Reservas: fila cronológica, expiração e notificações.
6. Relatórios e qualidade: consultas, testes, correções e apresentação.

Cada sprint deve entregar incremento integrado, revisão do backlog e demonstração. Critério de pronto: código revisado, testes relevantes aprovados, critérios de aceitação atendidos e documentação atualizada.

## Estimativa PERT — exemplo ilustrativo
Para uma funcionalidade estimada em O=2 dias, M=4 dias e P=8 dias: (2 + 4×4 + 8) / 6 = 4,33 dias. Premissas: equipe pequena, escopo delimitado e ambiente disponível. Não é medição real.

## Métricas planejadas
- Cobertura: linhas/branches cobertos por testes.
- Densidade de defeitos: defeitos por módulo ou tamanho.
- MTTD: média entre ocorrência e detecção.
- MTTR: média entre detecção e restauração.
- CSAT: média das avaliações de satisfação.
- Frequência de implantação: implantações por período.
- Taxa de falha em alterações: implantações com rollback/incidente dividido pelo total.
Nenhuma métrica foi medida nesta etapa.

## Práticas
Planning Poker para consenso de estimativas; programação em par em regras críticas; revisão de código por outro integrante; testes unitários e de integração em pipeline.
