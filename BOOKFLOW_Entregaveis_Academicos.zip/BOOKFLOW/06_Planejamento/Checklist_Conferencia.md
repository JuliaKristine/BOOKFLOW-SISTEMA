# Conferência com o enunciado

| Exigência | Entregável | Situação | Observação |
|---|---|---|---|
| Problema e oportunidade | Documento principal | Concluído como especificação | Validar com contexto real da biblioteca |
| Técnicas de levantamento | Documento principal | Parcial | Técnicas propostas; sem evidência de aplicação |
| Requisitos funcionais e não funcionais | Especificação de requisitos | Concluído como especificação | Requisitos enumerados |
| Interfaces Figma | Link_Figma.txt | Pendente de auditoria | Necessária conexão ao Figma |
| Modelo conceitual/lógico/físico | SQL + DER + documento | Parcial | SQL e relacionamentos descritos; exportar modelo visual do Workbench |
| Script SQL | bookflow.sql | Concluído como versão inicial | Executar em MySQL alvo e validar versão |
| Casos de uso | Casos_de_Uso.mmd | Parcial | Fonte Mermaid editável, não substitui diagrama UML final |
| Classes | Classes.mmd | Parcial | Revisar enums, operações e multiplicidades |
| Sequências | arquivos Sequencia_*.mmd | Concluído como especificação visual | Validar com implementação |
| Arquitetura | Arquitetura.mmd | Concluído como proposta | Implementação não verificada |
| Scrum/backlog/estimativas/métricas | Planejamento_Scrum_Backlog_Metricas.md | Concluído como planejamento | Story points e PERT são estimativas ilustrativas |
| Plano de testes | Plano_de_Testes.docx | Concluído como plano | Casos não executados |
| Frontend/backend funcionais | README | Pendente | Repositório não fornecido |
| Testes executados | Plano de testes | Pendente | Sem ambiente/código para executar |
