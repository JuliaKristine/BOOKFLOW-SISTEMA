# BOOKFLOW

Sistema web acadêmico para gerenciamento de empréstimos e reservas de livros em biblioteca.

## Stack proposta
- Frontend: React, TypeScript, Vite e Tailwind CSS
- Backend: Python, FastAPI e Pydantic
- Banco: MySQL
- Modelagem: MySQL Workbench
- Design: Figma
- Versionamento: Git/GitHub

## Estrutura
- `01_Documentacao/`: documento principal, requisitos e plano de testes
- `02_Banco_de_Dados/bookflow.sql`: schema inicial MySQL
- `03_Diagramas/`: fontes editáveis Mermaid
- `04_Prototipo/`: link e observações do protótipo
- `05_Implementacao/`: reservado para aplicação frontend/backend
- `06_Planejamento/`: backlog, sprints, estimativas e métricas

## Banco de dados
1. Instale MySQL 8.0 ou superior.
2. Execute `02_Banco_de_Dados/bookflow.sql` no MySQL Workbench.
3. O script cria o banco e as tabelas. O único registro inicial é a configuração padrão de empréstimo.
4. Dados de usuário e senhas devem ser criados pela aplicação; não há credenciais de demonstração.

## Execução da aplicação
O código executável do frontend e backend não foi fornecido nem auditado nesta entrega. Portanto, não existem comandos de execução confirmados. Quando a implementação for criada, documentar:
- instalação de dependências do frontend;
- configuração de `.env` do backend;
- conexão MySQL;
- execução dos servidores;
- migrações e testes automatizados.

## Segurança
- Senhas com Argon2id ou bcrypt.
- Autorização no backend em todas as rotas protegidas.
- Consultas parametrizadas/ORM.
- Segredos apenas em variáveis de ambiente.
- Transações para empréstimos, devoluções e reservas.

## Limitações conhecidas
- Figma ainda precisa de auditoria autenticada.
- Frontend e backend não estão implementados neste pacote.
- Casos de teste estão planejados, não executados.
- Integração de notificações depende de serviço e credenciais externos.
