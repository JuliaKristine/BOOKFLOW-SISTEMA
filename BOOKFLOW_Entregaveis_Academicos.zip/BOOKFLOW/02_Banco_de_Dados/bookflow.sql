CREATE DATABASE IF NOT EXISTS bookflow
  CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE bookflow;

CREATE TABLE usuarios (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  senha_hash VARCHAR(255) NOT NULL,
  tipo ENUM('ADMIN','BIBLIOTECARIO','LEITOR') NOT NULL DEFAULT 'LEITOR',
  status ENUM('ATIVO','INATIVO','BLOQUEADO') NOT NULL DEFAULT 'ATIVO',
  telefone VARCHAR(20),
  criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_usuario_status_tipo (status, tipo)
) ENGINE=InnoDB;

CREATE TABLE funcionarios (
  usuario_id BIGINT UNSIGNED PRIMARY KEY,
  matricula VARCHAR(30) NOT NULL UNIQUE,
  cargo VARCHAR(80),
  CONSTRAINT fk_func_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE categorias (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(80) NOT NULL UNIQUE,
  descricao VARCHAR(255)
) ENGINE=InnoDB;

CREATE TABLE editoras (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE autores (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(160) NOT NULL,
  UNIQUE KEY uq_autor_nome (nome)
) ENGINE=InnoDB;

CREATE TABLE livros (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  isbn VARCHAR(20) UNIQUE,
  titulo VARCHAR(220) NOT NULL,
  descricao TEXT,
  ano_publicacao YEAR,
  edicao VARCHAR(40),
  editora_id BIGINT UNSIGNED,
  categoria_id BIGINT UNSIGNED,
  capa_url VARCHAR(500),
  ativo BOOLEAN NOT NULL DEFAULT TRUE,
  criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_livro_editora FOREIGN KEY (editora_id) REFERENCES editoras(id)
    ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_livro_categoria FOREIGN KEY (categoria_id) REFERENCES categorias(id)
    ON DELETE SET NULL ON UPDATE CASCADE,
  INDEX idx_livro_titulo (titulo),
  INDEX idx_livro_categoria (categoria_id)
) ENGINE=InnoDB;

CREATE TABLE livro_autores (
  livro_id BIGINT UNSIGNED NOT NULL,
  autor_id BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (livro_id, autor_id),
  CONSTRAINT fk_la_livro FOREIGN KEY (livro_id) REFERENCES livros(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_la_autor FOREIGN KEY (autor_id) REFERENCES autores(id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE exemplares (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  livro_id BIGINT UNSIGNED NOT NULL,
  codigo_patrimonio VARCHAR(50) NOT NULL UNIQUE,
  status ENUM('DISPONIVEL','EMPRESTADO','RESERVADO','MANUTENCAO','BAIXADO') NOT NULL DEFAULT 'DISPONIVEL',
  localizacao VARCHAR(100),
  observacao VARCHAR(255),
  CONSTRAINT fk_exemplar_livro FOREIGN KEY (livro_id) REFERENCES livros(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  INDEX idx_exemplar_livro_status (livro_id, status)
) ENGINE=InnoDB;

CREATE TABLE configuracoes_emprestimo (
  id TINYINT UNSIGNED PRIMARY KEY,
  limite_emprestimos SMALLINT UNSIGNED NOT NULL DEFAULT 3,
  prazo_dias SMALLINT UNSIGNED NOT NULL DEFAULT 14,
  prazo_retirada_reserva_dias SMALLINT UNSIGNED NOT NULL DEFAULT 2,
  multa_diaria DECIMAL(8,2) NOT NULL DEFAULT 0.00,
  atualizado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT chk_limite CHECK (limite_emprestimos > 0),
  CONSTRAINT chk_prazo CHECK (prazo_dias > 0),
  CONSTRAINT chk_reserva_prazo CHECK (prazo_retirada_reserva_dias > 0),
  CONSTRAINT chk_multa CHECK (multa_diaria >= 0)
) ENGINE=InnoDB;

CREATE TABLE emprestimos (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  exemplar_id BIGINT UNSIGNED NOT NULL,
  leitor_id BIGINT UNSIGNED NOT NULL,
  funcionario_id BIGINT UNSIGNED NOT NULL,
  emprestado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  previsto_devolucao DATE NOT NULL,
  devolvido_em DATETIME NULL,
  status ENUM('ATIVO','CONCLUIDO','ATRASADO','CANCELADO') NOT NULL DEFAULT 'ATIVO',
  observacao VARCHAR(255),
  CONSTRAINT fk_emp_exemplar FOREIGN KEY (exemplar_id) REFERENCES exemplares(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_emp_leitor FOREIGN KEY (leitor_id) REFERENCES usuarios(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_emp_funcionario FOREIGN KEY (funcionario_id) REFERENCES funcionarios(usuario_id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  INDEX idx_emp_leitor_status (leitor_id, status),
  INDEX idx_emp_prazo_status (previsto_devolucao, status),
  INDEX idx_emp_exemplar_status (exemplar_id, status)
) ENGINE=InnoDB;

CREATE TABLE reservas (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  livro_id BIGINT UNSIGNED NOT NULL,
  leitor_id BIGINT UNSIGNED NOT NULL,
  solicitada_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status ENUM('AGUARDANDO','DISPONIVEL_RETIRADA','ATENDIDA','CANCELADA','EXPIRADA') NOT NULL DEFAULT 'AGUARDANDO',
  exemplar_id BIGINT UNSIGNED NULL,
  prazo_retirada DATETIME NULL,
  atendida_em DATETIME NULL,
  CONSTRAINT fk_res_livro FOREIGN KEY (livro_id) REFERENCES livros(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_res_leitor FOREIGN KEY (leitor_id) REFERENCES usuarios(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_res_exemplar FOREIGN KEY (exemplar_id) REFERENCES exemplares(id)
    ON DELETE SET NULL ON UPDATE CASCADE,
  INDEX idx_res_fila (livro_id, status, solicitada_em),
  INDEX idx_res_leitor (leitor_id, status)
) ENGINE=InnoDB;

CREATE TABLE devolucoes (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  emprestimo_id BIGINT UNSIGNED NOT NULL UNIQUE,
  funcionario_id BIGINT UNSIGNED NOT NULL,
  devolvida_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  condicao_exemplar VARCHAR(120),
  observacao VARCHAR(255),
  CONSTRAINT fk_dev_emprestimo FOREIGN KEY (emprestimo_id) REFERENCES emprestimos(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_dev_funcionario FOREIGN KEY (funcionario_id) REFERENCES funcionarios(usuario_id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE notificacoes (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  usuario_id BIGINT UNSIGNED NOT NULL,
  tipo ENUM('VENCIMENTO','ATRASO','RESERVA_DISPONIVEL','RESERVA_EXPIRADA','SISTEMA') NOT NULL,
  mensagem VARCHAR(500) NOT NULL,
  lida_em DATETIME NULL,
  criada_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_not_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  INDEX idx_not_usuario_data (usuario_id, criada_em)
) ENGINE=InnoDB;

INSERT INTO configuracoes_emprestimo
(id, limite_emprestimos, prazo_dias, prazo_retirada_reserva_dias, multa_diaria)
VALUES (1, 3, 14, 2, 0.00)
ON DUPLICATE KEY UPDATE id = id;

-- Dados de demonstração devem ser inseridos somente em ambiente de teste.
-- Senhas devem ser geradas pela aplicação com Argon2id ou bcrypt; nunca inserir senha em texto puro.
-- A regra "um empréstimo ativo por exemplar" deve ser garantida transacionalmente
-- pela aplicação (SELECT ... FOR UPDATE) e, opcionalmente, por índice único funcional
-- conforme a versão do MySQL adotada.
